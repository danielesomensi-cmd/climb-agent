# Vision — climb-agent

## North Star
App user-friendly che:
- pianifica macro-cicli 3–4 mesi con periodizzazione (stile Eric Hörst)
- genera un micro-piano giornaliero (“cosa fare oggi”)
- si aggiorna usando ciò che ho fatto davvero + feedback (fatigue, dolore, motivazione, qualità)

## Closed loop
Plan -> Resolve -> Execute -> Log -> Update

# Baseline session under test

- Path definito in: config/session_under_test.json
- Deve risolversi bene per:
  - home + hangboard
  - gym + blocx
